import pygame
import random
from sys import exit
import asyncio  # Required for web compatibility

# --- Configuration & Constants ---
GAME_WIDTH = 360
GAME_HEIGHT = 640
BIRD_X = GAME_WIDTH / 8
BIRD_Y = GAME_HEIGHT / 2
BIRD_WIDTH = 34
BIRD_HEIGHT = 24
PIPE_WIDTH = 64
PIPE_HEIGHT = 512

# States
START = 0
PLAYING = 1
GAME_OVER = 2

# --- Classes ---
class Bird(pygame.Rect):
    def __init__(self, img):
        super().__init__(BIRD_X, BIRD_Y, BIRD_WIDTH, BIRD_HEIGHT)
        self.image = img

class Pipe(pygame.Rect):
    def __init__(self, img, x, y):
        super().__init__(x, y, PIPE_WIDTH, PIPE_HEIGHT)
        self.image = img
        self.passed = False

# --- Game Functions ---
def draw_text(window, text, size, y_pos, color="white"):
    font = pygame.font.SysFont("Comic Sans MS", size, bold=True)
    render = font.render(text, True, color)
    rect = render.get_rect(center=(GAME_WIDTH / 2, y_pos))
    window.blit(render, rect)

# --- The Main Async Function ---
async def main():
    pygame.init()
    window = pygame.display.set_mode((GAME_WIDTH, GAME_HEIGHT))
    pygame.display.set_caption("Flappy Bird - Arish Kapali")
    clock = pygame.time.Clock()

    # Load Assets
    try:
        background_image = pygame.image.load("flappybirdbg.png").convert()
        bird_img = pygame.image.load("flappybird.png").convert_alpha()
        bird_image = pygame.transform.scale(bird_img, (BIRD_WIDTH, BIRD_HEIGHT))
        
        t_pipe_img = pygame.image.load("toppipe.png").convert_alpha()
        top_pipe_image = pygame.transform.scale(t_pipe_img, (PIPE_WIDTH, PIPE_HEIGHT))
        
        b_pipe_img = pygame.image.load("bottompipe.png").convert_alpha()
        bottom_pipe_image = pygame.transform.scale(b_pipe_img, (PIPE_WIDTH, PIPE_HEIGHT))
    except Exception as e:
        print(f"Asset Error: {e}. Using colored blocks instead.")
        background_image = pygame.Surface((GAME_WIDTH, GAME_HEIGHT))
        background_image.fill((135, 206, 235))
        bird_image = pygame.Surface((BIRD_WIDTH, BIRD_HEIGHT))
        bird_image.fill((255, 255, 0))
        top_pipe_image = pygame.Surface((PIPE_WIDTH, PIPE_HEIGHT))
        top_pipe_image.fill((34, 139, 34))
        bottom_pipe_image = pygame.Surface((PIPE_WIDTH, PIPE_HEIGHT))
        bottom_pipe_image.fill((34, 139, 34))

    # Initialize Variables
    bird = Bird(bird_image)
    pipes = []
    gravity = 0.4
    velocity_y = 0
    score = 0
    game_state = START
    
    # MANUAL TIMER INSTEAD OF pygame.time.set_timer
    pipe_spawn_timer = 0 

    # --- Main Loop ---
    while True:
        # 1. Event Handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

            if event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN:
                if event.type == pygame.KEYDOWN and event.key not in (pygame.K_SPACE, pygame.K_UP):
                    continue 
                
                if game_state == START:
                    game_state = PLAYING
                
                if game_state == PLAYING:
                    velocity_y = -7
                
                elif game_state == GAME_OVER:
                    # Reset Game
                    bird.y = BIRD_Y
                    pipes.clear()
                    score = 0
                    velocity_y = 0
                    pipe_spawn_timer = 0
                    game_state = START

        # 2. Logic Updates
        if game_state == PLAYING:
            # Gravity & Bird Movement
            velocity_y += gravity
            bird.y += velocity_y
            
            # Floor/Ceiling Death
            if bird.y <= 0 or bird.y >= GAME_HEIGHT - BIRD_HEIGHT:
                game_state = GAME_OVER

            # Manual Pipe Spawning (Every 90 frames / 1.5 seconds)
            pipe_spawn_timer += 1
            if pipe_spawn_timer >= 90:
                gap = 160
                random_y = random.randint(150, 450)
                pipes.append(Pipe(top_pipe_image, GAME_WIDTH, random_y - PIPE_HEIGHT - (gap/2)))
                pipes.append(Pipe(bottom_pipe_image, GAME_WIDTH, random_y + (gap/2)))
                pipe_spawn_timer = 0

            # Pipe Movement & Collision
            for pipe in pipes:
                pipe.x -= 3
                if bird.colliderect(pipe):
                    game_state = GAME_OVER
                if not pipe.passed and pipe.x + PIPE_WIDTH < bird.x:
                    pipe.passed = True
                    score += 0.5 # 0.5 for each pipe in the pair

            # Remove old pipes
            pipes = [p for p in pipes if p.x + PIPE_WIDTH > 0]

        # 3. Drawing
        window.blit(background_image, (0, 0))
        for pipe in pipes:
            window.blit(pipe.image, pipe)
        window.blit(bird.image, bird)

        # UI Overlays
        if game_state == START:
            draw_text(window, "FLAPPY BIRD", 40, GAME_HEIGHT / 4)
            draw_text(window, "Tap or Space to Start", 22, GAME_HEIGHT / 2)
        elif game_state == PLAYING:
            draw_text(window, str(int(score)), 45, 60)
        elif game_state == GAME_OVER:
            draw_text(window, "GAME OVER", 40, GAME_HEIGHT / 4)
            draw_text(window, f"Score: {int(score)}", 30, GAME_HEIGHT / 2)
            draw_text(window, "Tap to Restart", 20, GAME_HEIGHT * 0.7)

        # Permanent Credit
        draw_text(window, "Developed by Arish Kapali", 16, GAME_HEIGHT - 30, "black")

        # 4. Refresh Screen
        pygame.display.update()
        clock.tick(60)
        
        # REQUIRED FOR WEB: Yield control to browser
        await asyncio.sleep(0)

# Entry point
if __name__ == "__main__":
    asyncio.run(main())